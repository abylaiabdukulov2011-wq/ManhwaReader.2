package com.example.manhwareader;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;
import java.io.*;

public class MainActivity extends Activity {
    private PdfRenderer renderer;
    private ParcelFileDescriptor pfd;
    private PdfReaderView reader;
    private TextView title;
    private LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        if (getIntent() != null && getIntent().getData() != null) openUri(getIntent().getData());
        else if (getIntent() != null && getIntent().getParcelableExtra(Intent.EXTRA_STREAM) != null)
            openUri((Uri)getIntent().getParcelableExtra(Intent.EXTRA_STREAM));
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xffeeeeee);
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(8, 8, 8, 8);
        bar.setBackgroundColor(0xfffafafa);

        Button open = new Button(this); open.setText("Открыть PDF");
        open.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, 10);
        });
        title = new TextView(this); title.setText("Манхва PDF"); title.setTextSize(16);
        title.setSingleLine(true); title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setGravity(Gravity.CENTER_VERTICAL);
        Button fit = new Button(this); fit.setText("По ширине");
        fit.setOnClickListener(v -> { if(reader != null) reader.fitWidth(); });
        Button lock = new Button(this); lock.setText("🔓");
        lock.setOnClickListener(v -> {
            if(reader != null) {
                boolean locked = reader.toggleLock();
                lock.setText(locked ? "🔒" : "🔓");
                Toast.makeText(this, locked ? "Масштаб зафиксирован" : "Масштаб можно менять", Toast.LENGTH_SHORT).show();
            }
        });
        bar.addView(open, new LinearLayout.LayoutParams(-2, -2));
        bar.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        bar.addView(fit, new LinearLayout.LayoutParams(-2, -2));
        bar.addView(lock, new LinearLayout.LayoutParams(-2, -2));
        root.addView(bar);
        reader = new PdfReaderView(this);
        root.addView(reader, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if(req == 10 && res == RESULT_OK && data != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch(Exception ignored) {}
            openUri(uri);
        }
    }

    private void openUri(Uri uri) {
        try {
            closePdf();
            File file = new File(getCacheDir(), "current_manhwa.pdf");
            try(InputStream in = getContentResolver().openInputStream(uri);
                OutputStream out = new FileOutputStream(file)) {
                if(in == null) throw new IOException("Не удалось прочитать файл");
                byte[] buf = new byte[65536]; int n;
                while((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
            renderer = new PdfRenderer(pfd);
            reader.setDocument(renderer);
            title.setText(getName(uri));
        } catch(Exception e) {
            Toast.makeText(this, "Не удалось открыть PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private String getName(Uri uri) {
        String name = "Манхва PDF";
        try(Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if(c != null && c.moveToFirst()) {
                int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if(ix >= 0) name = c.getString(ix);
            }
        } catch(Exception ignored) {}
        return name;
    }

    private void closePdf() {
        if(reader != null) reader.setDocument(null);
        try { if(renderer != null) renderer.close(); } catch(Exception ignored) {}
        try { if(pfd != null) pfd.close(); } catch(Exception ignored) {}
        renderer = null; pfd = null;
    }
    @Override protected void onDestroy() { closePdf(); super.onDestroy(); }
}
