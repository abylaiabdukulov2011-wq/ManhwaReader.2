package com.example.manhwareader;

import android.content.Context;
import android.graphics.*;
import android.graphics.pdf.PdfRenderer;
import android.view.*;
import android.widget.Toast;
import java.util.*;

public class PdfReaderView extends View {
    private PdfRenderer doc;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final LinkedHashMap<Integer, Bitmap> cache = new LinkedHashMap<Integer, Bitmap>(5, .75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Integer, Bitmap> e) {
            if(size() > 4) { e.getValue().recycle(); return true; } return false;
        }
    };
    private float scale = 1f, fitScale = 1f, scrollY = 0, lastY, downX;
    private boolean dragging = false, locked = false;
    private ScaleGestureDetector scaleDetector;
    private float oldScale = 1f;
    private int bg = 0xffd8d8d8;

    public PdfReaderView(Context c) {
        super(c); setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        scaleDetector = new ScaleGestureDetector(c, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector d) {
                if(!locked && doc != null) {
                    float prev = scale;
                    scale = Math.max(fitScale * .5f, Math.min(fitScale * 4f, scale * d.getScaleFactor()));
                    float focus = d.getFocusY();
                    scrollY = (scrollY + focus) * (scale / prev) - focus;
                    clampScroll(); invalidate();
                }
                return true;
            }
        });
    }

    public void setDocument(PdfRenderer r) {
        clearCache(); doc = r; scrollY = 0; locked = false;
        if(doc != null && doc.getPageCount() > 0) {
            PdfRenderer.Page p = doc.openPage(0);
            fitScale = getWidth() > 0 ? (float)getWidth() / p.getWidth() : 1f;
            p.close(); scale = fitScale;
        }
        invalidate();
    }
    public boolean toggleLock() { locked = !locked; return locked; }
    public void fitWidth() {
        if(doc == null || doc.getPageCount() == 0) return;
        PdfRenderer.Page p = doc.openPage(0);
        fitScale = (float)getWidth() / p.getWidth(); p.close();
        scale = fitScale; scrollY = 0; invalidate();
    }
    private void clearCache() { for(Bitmap b: cache.values()) if(!b.isRecycled()) b.recycle(); cache.clear(); }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w,h,ow,oh);
        if(doc != null && w > 0 && doc.getPageCount() > 0 && scale == 1f) fitWidth();
    }

    private float pageHeight(int index) {
        PdfRenderer.Page p = doc.openPage(index);
        float h = p.getHeight() * scale; p.close(); return h;
    }
    private float totalHeight() {
        if(doc == null) return getHeight();
        float sum = 0;
        for(int i=0;i<doc.getPageCount();i++) sum += pageHeight(i) + 12;
        return sum;
    }
    private void clampScroll() { scrollY = Math.max(0, Math.min(scrollY, Math.max(0, totalHeight()-getHeight()))); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); c.drawColor(bg);
        if(doc == null) {
            paint.setColor(0xff555555); paint.setTextSize(17);
            c.drawText("Открой PDF из Telegram или телефона", 24, 60, paint); return;
        }
        float top = 8 - scrollY;
        for(int i=0;i<doc.getPageCount();i++) {
            PdfRenderer.Page p = doc.openPage(i);
            float w = p.getWidth()*scale, h = p.getHeight()*scale;
            float left = (getWidth()-w)/2f;
            if(top+h >= -10 && top <= getHeight()+10) {
                Bitmap b = cache.get(i);
                if(b == null || b.isRecycled()) {
                    b = Bitmap.createBitmap(p.getWidth(), p.getHeight(), Bitmap.Config.ARGB_8888);
                    p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    cache.put(i,b);
                }
                c.drawBitmap(b, null, new RectF(left, top, left+w, top+h), paint);
            }
            p.close();
            top += h + 12;
            if(top > getHeight()+100) break;
        }
    }

    @Override public boolean onTouchEvent(android.view.MotionEvent e) {
        scaleDetector.onTouchEvent(e);
        switch(e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lastY = e.getY(); downX = e.getX(); dragging = true; return true;
            case MotionEvent.ACTION_POINTER_DOWN: dragging = false; return true;
            case MotionEvent.ACTION_MOVE:
                if(!scaleDetector.isInProgress() && e.getPointerCount()==1 && dragging) {
                    float dy = lastY - e.getY(); scrollY += dy; lastY = e.getY();
                    clampScroll(); invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                dragging = false; performClick(); return true;
        }
        return true;
    }
    @Override public boolean performClick() { super.performClick(); return true; }
}
